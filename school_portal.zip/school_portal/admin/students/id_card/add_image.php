<?php require(__DIR__.'/../../views/header.php');
?>
    <link href="../../assets/css/styles.css" rel="stylesheet" />
    <div class="container-fluid px-4">
        <h1 class="mt-4">Dashboard</h1>
        <div class="card">
            <div class="card-header">
                <?php alertMessage();?>
                <h4 class="mb-0">Upload Student Image
                    <a href="id_card.php" class="btn btn-danger float-end">Back</a>
                </h4>
            </div>
            <div class="card-body">
                <form action="code.php" method="post" enctype="multipart/form-data">
                    <?php
                    if(isset($_GET['pk'])){
                        if($_GET['pk']!= '') {
                            $studentId = $_GET['pk'];
                        }else{
                            echo '<h5>No ID Found</h5>';
                            return false;
                        }
                    }else{
                        echo '<h5>No Id given in params!</h5>';
                        return false;
                    }
                    $studentData = getById('student',$studentId);
                    if($studentData){
                        if($studentData ['status']==200){
                            ?>
                            <input type="hidden" name="pk" value="<?= $studentData ['data']['pk']; ?>">
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <label for="">Name </label>
                                    <input disabled type="text" name="name" required value="<?= $studentData ['data']['name']; ?>" class="form-control"/>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="">Class </label>
                                    <input disabled type="text" name="class" required value="<?= $studentData ['data']['class']; ?>" class="form-control"/>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="">Section </label>
                                    <input disabled type="text" name="section" required value="<?= $studentData ['data']['section']; ?>" class="form-control"/>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="">Student Image </label>
                                    <input type="file" name="image" class="form-control"/>
                                </div>
                                <div class="col-md-3 mb-3 text-end">
                                    <button type="submit" name="updateImage" class="btn btn-primary">Update</button>
                                </div>
                            </div>
                            <?php $id = checkParamId('pk');
                            ?>

                            <?php
                        }
                        else{
                            echo '<h5>'.$studentData['message'].'</h5>>';
                        }
                    }else{
                        echo "Something Went Wrong";
                        return false;
                    }
                    ?>
                </form>
            </div>
        </div>
    </div>
<?php include("../../views/footer.php") ?>