<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require('../../../config/function.php');
if (isset($_GET['pk'])) {
    if ($_GET['pk'] != '') {
        $studentId = $_GET['pk'];

    } else {
        echo '<h5>No ID Found</h5>';
        return false;
    }
} else {
    echo '<h5>No Id given in params!</h5>';
    return false;
}
$data = getIDCard($studentId);
foreach ($data as $item):
    $columns = array_keys($item);
    $values = array_values($item);
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Background Image Example</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-image: url('Professional Portrait Business Card (1).png');
                background-size: 500px;
                background-position: top;
                background-repeat: no-repeat;
                padding: 10px;
                margin: 0;
            }

            .card  {
                width: 300px;
                height: 200px;
                background-color: rgba(255, 255, 255, 0.8); /* Background color with opacity */
                border: 1px solid #cccccc;
                border-radius: 10px;
                padding: 20px;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                margin: 20px auto; /* Center the card horizontally */
            }

            .card h1 {
                font-size: 20px;
                margin-bottom: 10px;
            }

            .card p {
                font-size: 16px;
                margin-bottom: 5px;
            }

            .card img {
                width: 80px;
                height: 80px;
                border-radius: 50%;
                margin-right: 10px;
                float: left;
            }

            .id-card-name {
                text-align: center;

            }

            .id-card-details {
                text-align: center;

            }
        </style>
    </head>
    <body>
    <div class="id-card-name" style="margin-top: 190px">
        <div class="student_image"><img src="<?php echo $item['image']; ?>"/></div>
        <h2><strong>Name:</strong> <?= $item['name'] ?></h2>
        <div class="id-card-details">
            <p><strong>Roll Number:</strong> <?= $item['pk'] ?></p>
            <p><strong>Class:</strong> <?= $item['class'] ?></p>
            <p><strong>Section:</strong> <?= $item['section'] ?></p>
            <p><strong>Father Name:</strong> <?= $item['father_name'] ?></p>
            <p><strong>Mother Name:</strong> <?= $item['mother_name'] ?></p>
        </div>
    </div>
    </body>
    </html>
<?php
endforeach;
?>
