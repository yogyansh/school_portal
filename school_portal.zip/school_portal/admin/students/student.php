<?php

include(__DIR__.'/../views/header.php');

?>


    <link href="../assets/css/styles.css" rel="stylesheet" />
    <div class="container-fluid px-4">
        <h1 class="mt-4">Dashboard</h1>
        <div class="card mt-4 shadow">
            <div class="card-header">
                <h4 class="mb-0">Students
                    <a href="student-create.php" class="btn btn-dark float-end">Add Student</a>
                </h4>
            </div>
            <div class="card-body">
                <?php alertMessage();?>
                <?php
                $student = getAll('student');
                if(!$student){
                    echo 'Something went wrong';
                }
                if(mysqli_num_rows($student)>0){
                    ?>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead>
                        <tr>
                            <th>Roll Number</th>
                            <th>Name</th>
                            <th>Class</th>
                            <th>Section</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        foreach ($student as $item):  ?>
                            <tr>
                                <td><?= $item['pk'] ?></td>
                                <td><?= $item['name'] ?></td>
                                <td><?= $item['class'] ?></td>
                                <td><?= $item['section'] ?></td>
                                <td>
                                    <a href="parents-details.php?pk=<?=$item['pk'] ?>" class="btn btn-primary btn-sm">Parents Details</a>
                                    <a href="reopot-card.php?pk=<?=$item['pk'] ?>" class="btn btn-primary btn-sm">Report Card</a>
                                </td>
                            </tr>
                        <?php endforeach;?>

                        </tbody>
                    </table>
                </div>
                <?php
                }
                else{
                    ?>
                    <tr>
                        <h4 class="mb-0">No record found</h4>
                    </tr>
                    <?php
                }
                ?>
            </div>
        </div>
    </div>
<?php include("../views/footer.php") ?>