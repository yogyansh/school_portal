<?php require(__DIR__.'/../views/header.php');
?>
    <link href="../assets/css/styles.css" rel="stylesheet" />
    <div class="container-fluid px-4">
        <h1 class="mt-4">Dashboard</h1>
        <div class="card">
            <div class="card-header">
                <?php alertMessage();?>
                <h4 class="mb-0">Edit Student
                    <a href="student.php" class="btn btn-danger float-end">Back</a>
                </h4>
            </div>
            <div class="card-body">
                <form action="code.php" method="post">
                    <?php
                    if(isset($_GET['pk'])){
                        if($_GET['pk']!= '') {
                            $studentId = $_GET['pk'];
                        }else{
                            echo '<h5>No ID Found</h5>';
                            return false;
                        }
                    }else{
                        echo '<h5>No Id given in params!</h5>';
                            return false;
                    }
                    $studentData = getById('student',$studentId);
                    if($studentData){
                        if($studentData ['status']==200){
                            ?>
                                <input type="hidden" name="student_pk" value="<?= $studentData ['data']['pk']; ?>">
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <label for="">Name </label>
                                    <input type="text" name="name" required value="<?= $studentData ['data']['name']; ?>" class="form-control"/>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="">Class </label>
                                    <input type="text" name="class" required value="<?= $studentData ['data']['class']; ?>" class="form-control"/>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="">Section </label>
                                    <input type="text" name="section" required value="<?= $studentData ['data']['section']; ?>" class="form-control"/>
                                </div>
                                <div class="col-md-3 mb-3 text-end">
                                    <button type="submit" name="updateStudent" class="btn btn-primary">Update</button>
                                </div>
                            </div>
                            <?php
                        }
                        else{
                            echo '<h5>'.$studentData['message'].'</h5>>';
                        }
                    }else{
                        echo "Something Went Wrong";
                        return false;
                    }
                    ?>
                </form>
            </div>
        </div>
    </div>
<?php include("../views/footer.php") ?>