<?php
require(__DIR__.'/views/header.php');
?>
    <link href="assets/css/styles.css" rel="stylesheet" />
<div class="container-fluid px-4">
    <h1 class="mt-4">Dashboard</h1>
    <div class="card mt-4 shadow">
        <div class="card-header">
            <h4 class="mb-0">Admins/Staff
            <a href="admins-create.php" class="btn btn-primary float-end">Add admin</a>
            </h4>
        </div>
        <div class="card-body">
            <?php alertMessage();?>
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $admins = getAll('admins');
                    if(!$admins){
                        echo 'Something went wrong';
                    }
                    if(mysqli_num_rows($admins)>0){
                        ?>
                           <?php
                                foreach ($admins as $adminItem):  ?>
                        <tr>
                            <td><?= $adminItem['pk'] ?></td>
                            <td><?= $adminItem['name'] ?></td>
                            <td><?= $adminItem['email'] ?></td>
                                    <td>
                                        <a href="admins-edit.php?pk=<?=$adminItem['pk'] ?>" class="btn btn-success btn-sm">Edit</a>
                                        <a href="admins-delete.php?pk=<?=$adminItem['pk'] ?>" class="btn btn-danger btn-sm">Delete</a>
                                    </td>
                        </tr>
                                <?php endforeach;?>

                    </tbody>
                </table>
            </div>
                <?php
            }
            else{
                ?>
                <tr>
                    <h4 class="mb-0">No record found</h4>
                </tr>
                <?php
            }
            ?>
        </div>
    </div>
</div>
<?php include("views/footer.php") ?>