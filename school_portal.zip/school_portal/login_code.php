<?php
require(__DIR__.'/views/header.php');
global $conn;
if(isset($_POST['loginBtn'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    if($email != '' && $password != ''){
        $query = "SELECT * FROM admins WHERE email='$email' LIMIT 1";
        $result = mysqli_query($conn, $query);
        if($result){
            if(mysqli_num_rows($result)==1){
                $row = mysqli_fetch_assoc($result);
//                $hashedPassword = $row['password'];
//
//                if(!password_verify($password,$hashedPassword)){
//                    redirect('login.php','Invalid Password');
//                }
                $_SESSION['loggedIn']=true;
                $_SESSION['loggedInUser']=[
                    'user_id'=>$row['pk'],
                    'name'=>$row['name'],
                    'email'=>$row['email'],
                    'phone'=>$row['phone_number']
                ];
                redirect('admin/index.php','Logged In Successfully');

            }else{
                redirect('login.php','No user found!');
            }
        }else{
            redirect('login.php','Something went wrong!');
        }
    }
    else{
        redirect('login.php','All field are required!');
    }
}
?>