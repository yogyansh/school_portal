<?php include('views/header.php');?>

<div class="py-5">
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <h1>School Portal</h1>
                <a href="login.php" class="btn btn-primary mt-4">Login</a>
            </div>

        </div>

    </div>

</div>


<?php include ('views/footer.php');?>




