<?php
require(__DIR__.'/../views/header.php');
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>

    <link href="../assets/css/styles.css" rel="stylesheet" />
    <div class="container-fluid px-4">
        <h1 class="mt-4">Student Portal</h1>
        <div class="card">
            <div class="card-header">
                <h4 class="mb-0">Add Student
                    <a href="student.php" class="btn btn-primary float-end">Back</a>
                </h4>
            </div>
            <div class="card-body">
                <form action="code.php" method="post">
                    <?php alertMessage();?>
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label for="">Name *</label>
                            <input type="text" name="name" required class="form-control"/>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for="">Class *</label>
                            <input type="text" name="class" required class="form-control"/>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for="">Section *</label>
                            <input type="text" name="section" required class="form-control"/>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for="">Father Name *</label>
                            <input type="text" name="father_name" required class="form-control" />
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for="">Father Phone *</label>
                            <input type="text" name="father_phone" required class="form-control"/>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for="">Mother Name *</label>
                            <input type="text" name="mother_name" required class="form-control"/>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for="">Mother Phone *</label>
                            <input type="text" name="mother_phone" required class="form-control"/>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for="">Address *</label>
                            <input type="text" name="address" required class="form-control"/>
                        </div>
                        <div class="col-md-3 mb-3 text-end">
                            <button type="submit" name="saveStudent" class="btn btn-primary">Save</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php include("../views/footer.php") ?>