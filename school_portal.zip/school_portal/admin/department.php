<?php

include(__DIR__.'/views/header.php');

?>


    <link href="assets/css/styles.css" rel="stylesheet" />
    <div class="container-fluid px-4">
        <h1 class="mt-4">Dashboard</h1>
        <div class="card mt-4 shadow">
            <div class="card-header">
                <h4 class="mb-0">Department
                    <a href="Department-create.php" class="btn btn-primary float-end">Add Department</a>
                </h4>
            </div>
            <div class="card-body">
                <?php
                $Department = getAll('department');
                if(!$Department){
                    echo 'Something went wrong';
                }
                if(mysqli_num_rows($Department)>0){
                    ?>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        foreach ($Department as $item):  ?>
                            <tr>
                                <td><?= $item['pk'] ?></td>
                                <td><?= $item['name'] ?></td>
                                <td>
                                    <?php
                                        if($item['status']==1){
                                            echo '<span class="badge bg-danger">Hidden</span>';
                                        }
                                        else{
                                            echo '<span class="badge bg-danger">Visible</span>';
                                        }
                                    ?>
                                </td>
                                <td>
                                    <a href="department-edit.php?pk=<?=$item['pk'] ?>" class="btn btn-success btn-sm">Edit</a>
                                    <a href="department-delete.php?pk=<?=$item['pk'] ?>" class="btn btn-danger btn-sm">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach;?>

                        </tbody>
                    </table>
                </div>
                <?php
                }
                else{
                    ?>
                    <tr>
                        <h4 class="mb-0">No record found</h4>
                    </tr>
                    <?php
                }
                ?>
            </div>
        </div>
    </div>
<?php include("views/footer.php") ?>