<?php
require(__DIR__.'/views/header.php');
$paraResult = checkParamId('pk');
if(is_numeric($paraResult)){
    echo $paraResult;
    $department= getById('department',$paraResult);
    if($department['status']==200){
        $departmentDelete = delete('department',$paraResult);
        if($departmentDelete){
            redirect('department.php','Department Deleted Successfully');
        }
        else{
            redirect('department.php','Something Went Wrong');
        }
    }else{
        redirect('department.php',$department['message']);
    }
}else{
    redirect('department.php','Something Went Wrong');
}
?>