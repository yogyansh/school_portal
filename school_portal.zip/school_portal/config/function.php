<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require("con.php");

function validate($inputData)
{
    global $conn;
    $validatedData = mysqli_real_escape_string($conn, $inputData);
    return trim($validatedData);
}
function alertMessage()
{
if(isset ($_SESSION['status'])){
    echo'  <div class="alert alert-warning alert-dismissible fade show" role="alert">
           <h6>'.$_SESSION['status'].'</h6>
           <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
           </div>';
    unset ($_SESSION['status']);
    }
}
function insertData($tableName,$data)
{
    global $conn;

    $columns = array_keys($data);
    $values = array_values($data);

    $finalColumns = implode(',', $columns);
    $finalValues = "'" . implode("','", $values) . "'";


    $query = "INSERT INTO $tableName ($finalColumns)  values ($finalValues)";
    $result = mysqli_query($conn, $query);
    return $result;
}
    function update($tableName, $id, $data)
    {
        global $conn;

        $updateDataString = "";
        foreach ($data as $column => $value) {
            $updateDataString .= $column . "='" . $value . "',";
        }
        $finalUpdateData = rtrim($updateDataString, ',');
        $query = "UPDATE $tableName SET $finalUpdateData WHERE pk='$id'";
        $result = mysqli_query($conn, $query);
        return $result;
    }
    function getAll($tableName){
        global $conn;

        $query = "SELECT * FROM $tableName";

        return mysqli_query($conn, $query);
    }
    function getParent($tableName,$id){
        global $conn;
        $query = "SELECT father_name,father_phone,mother_name,mother_phone,mother_phone,address,s.name as student_name FROM $tableName t join student s where t.student_pk= '$id'";

        return mysqli_query($conn, $query);
    }

    function getById($tableName, $id){
        global $conn;

        $query = "SELECT * FROM $tableName WHERE pk='$id' LIMIT 1";
        $result = mysqli_query($conn, $query);
        if($result){
                if(mysqli_num_rows($result) == 1){
                    $row = mysqli_fetch_assoc($result);
                    $response = [
                        'status' => 200,
                        'data' => $row,
                        'message' => 'RECORD FOUND'
                    ];
                    return $response;
                }
                else{
                    $response = [
                        'status' => 404,
                        'message' => 'DATA NOT FOUND'
                    ];
                    return $response;
                }
        }else{
            $response = [
                'status' => 501,
                'message' => 'SOMETHING WENT WRONG'
            ];
            return $response;

        }
    }
    function delete($tableName, $id){
        global $conn;

        $query = "DELETE FROM $tableName WHERE pk='$id' LIMIT 1";
        $result = mysqli_query($conn, $query);
        return $result;
    }

function checkParamId($type){
    if(isset($_GET[$type])){
        if($_GET[$type]!= ''){
            return $_GET[$type];
        }else{
            return '<h5>No Id Found</h5>';
        }
   }else{
        return '<h5>No Id Given</h5>>';
    }
}

function logoutSession()
{
    unset($_SESSION['loggedIn']);
    unset($_SESSION['loggedInUser']);
}
function getIDCard($id)
{
    global $conn;
    $query = "SELECT s.pk,s.name,s.class,s.section,p.father_name,p.mother_name FROM student s join parents p WHERE s.pk='$id' LIMIT 1";
    $result = mysqli_query($conn, $query);
    return $result;
}

function imageUpload($data, $id)
{
    global $conn;
    $image = $data['image'];
    $sql = "UPDATE student SET image='$image' WHERE pk='$id'";
    return mysqli_query($conn, $sql);
}

?>
<?php
function redirect($url, $status) {
    $_SESSION['status'] = $status;
    echo "<script>window.location.href='$url';</script>";
    exit(0);
}
?>
