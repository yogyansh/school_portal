<?php
require(__DIR__.'/../views/header.php');
global $conn;
if(isset($_POST['saveStudent'])){
    $name = $_POST['name'];
    $class = $_POST['class'];
    $section = $_POST['section'];
    $father_name = $_POST['father_name'];
    $father_phone = $_POST['father_phone'];
    $mother_name = $_POST['mother_name'];
    $mother_phone = $_POST['mother_phone'];
    $address = $_POST['address'];

    $studentData = [
        "name" => $name,
        "class" => $class,
        "section" => $section
    ];

    $getResultStudent = insertData('student', $studentData);
    $student_pk = mysqli_insert_id($conn);
    if($student_pk!= null) {
        $parentData = [
            "father_name" => $father_name,
            "father_phone" => $father_phone,
            "mother_name" => $mother_name,
            "mother_phone" => $mother_phone,
            "address" => $address,
            "student_pk" => $student_pk
        ];

        $getResultParent = insertData('parents', $parentData);
        if($getResultParent && $getResultStudent){
            redirect('student.php', 'Record inserted successfully!');
        } else {
            redirect('student-create.php', 'Something went wrong!');
        }
    } else {
    redirect('student-create.php', 'Please fill required details!');
    }
}

if(isset($_POST['updateStudent'])){
    $studentId = $_POST['student_pk'];
    $studentUpdate = getById('student',$studentId);

    $name = $_POST['name'];
    $class = $_POST['class'];
    $section = $_POST['section'];

    $data = [
            "name" => $name,
            "class" => $class,
            "section" => $section
    ];

        $getResult = update('student',$studentId, $data);
        if ($getResult) {
            redirect('student-edit.php', 'Record update successfully!');
        } else {
            redirect('student-edit.php', 'Something went wrong!');
        }
}