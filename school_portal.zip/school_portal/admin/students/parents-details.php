<?php include(__DIR__.'/../views/header.php'); ?>

<?php
$id = checkParamId('pk');

$studentProfile = getParent('parents', $id);
if (!$studentProfile) {
    echo 'Something went wrong';
}

$studentProfileDetails=mysqli_fetch_assoc($studentProfile);
?>

<link href="assets/css/styles.css" rel="stylesheet" />
<div class="container-fluid px-4">
    <h1 class="mt-4">Dashboard</h1>
    <div class="card mt-4 shadow">
        <div class="card-header">
            <a href="student.php" class="btn btn-primary float-end">Back</a>
            <h4 class="mb-0">Parents details of <?php echo $studentProfileDetails['student_name']?></h4>
        </div>
        <div class="card-body">

            <?php if (mysqli_num_rows($studentProfile) > 0) : ?>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead>
                        <tr>
                            <th>Father's Name</th>
                            <th>Father's Phone</th>
                            <th>Mother's Name</th>
                            <th>Mother's Phone</th>
                            <th>Address</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
//echo '<pre>';
//                        print_r(mysqli_fetch_assoc($parents));
//                        echo '</pre>';

//                        echo $getItem["father_name"];
//
                        ?>
                            <tr>
                                <td><?= $studentProfileDetails['father_name'] ?></td>
                                <td><?= $studentProfileDetails['father_phone'] ?></td>
                                <td><?= $studentProfileDetails['mother_name'] ?></td>
                                <td><?= $studentProfileDetails['mother_phone'] ?></td>
                                <td><?= $studentProfileDetails['address'] ?></td>
                            </tr>
                        <?php ?>

                        </tbody>
                    </table>
                </div>
            <?php else : ?>
                <h4 class="mb-0">No record found </h4>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php include("../views/footer.php") ?>
