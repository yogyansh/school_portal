<?php

require(__DIR__.'/../../views/header.php');

?>
    <link href="../../assets/css/styles.css" rel="stylesheet" />
    <div class="container-fluid px-4">
        <h1 class="mt-4">Print ID Cards</h1>
        <div class="card mt-4 shadow">
            <div class="card-header">
                <h4 class="mb-0">Students
                </h4>
            </div>
            <div class="card-body">
                <?php alertMessage();?>
                <?php
                $student = getAll('student');
                if(!$student){
                    echo 'Something went wrong';
                }
                if(mysqli_num_rows($student)>0){
                    ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered">
                            <thead>
                            <tr>
                                <th>Roll Number</th>
                                <th>Name</th>
                                <th>Class</th>
                                <th>Section</th>
                                <th>ID Card</th>
                                <th>Image</th>

                            </tr>
                            </thead>
                            <tbody>
                            <?php
                            foreach ($student as $item):  ?>
                                <tr>
                                    <td><?= $item['pk'] ?></td>
                                    <td><?= $item['name'] ?></td>
                                    <td><?= $item['class'] ?></td>
                                    <td><?= $item['section'] ?></td>
                                    <td><?= $item['image'] ?></td>
                                    <td>
                                        <a href="id_card_template.php?pk=<?=$item['pk'] ?>"  class="btn btn-primary btn-sm">Print ID Card</a>
                                    </td>
                                    <td>
                                        <a href="add_image.php?pk=<?=$item['pk'] ?>"  class="btn btn-primary btn-sm">Add Image</a>
                                    </td>
                                </tr>
                            <?php endforeach;?>
                            <?php $id = checkParamId('pk');?>

                            </tbody>
                        </table>
                    </div>
                    <?php
                }
                else{
                    ?>
                    <tr>
                        <h4 class="mb-0">No record found</h4>
                    </tr>
                    <?php
                }
                ?>
            </div>
        </div>
    </div>
<?php include("../../views/footer.php") ?>