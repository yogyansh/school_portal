<?php
require ('../../views/header.php');
require('../../../fpdf186/fpdf.php');

error_reporting(E_ALL);
ini_set('display_errors', 1);
if(isset($_POST['printId'])) {
    $studentId = $_POST['pk'];
    if (isset($_GET['pk'])) {
        if ($_GET['pk'] != '') {
            $studentId = $_GET['pk'];
        } else {
            echo '<h5>No ID Found</h5>';
            return false;
        }
    } else {
        echo '<h5>No Id given in params!</h5>';
        return false;
    }

    $getData = getIDCard($studentId);
    if ($getData) {
        redirect('id_card.php', 'ID card Downloaded Successfully');
    } else {
        redirect('id_card.php', 'Something went wrong!');
    }
}
if(isset($_POST['updateImage'])) {
    $studentId = $_POST['pk'];
    $finalImage = "";

    if ($_FILES['image']['size'] > 0) {
        $path = "admin/students/id_card/student_images";
        $image_ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        $fileName = time() . '.' . $image_ext;
        $uploadPath = $path . '/' . $fileName;

        move_uploaded_file($_FILES['image']['tmp_name'], $uploadPath);
        echo 12;
        $finalImage = "admin/students/id_card/student_images/" . $fileName;

        $data = [
            'image' => $finalImage
        ];

        $getResult = imageUpload($data, $studentId);
        if ($getResult) {
            redirect('id_card.php', 'Record update successfully!');
        } else {
            redirect('id_card.php', 'Something went wrong!');
        }
        redirect('id_card.php', 'Failed to move uploaded file!');
    } else {
        redirect('id_card.php', 'No file uploaded!');

    }
}

