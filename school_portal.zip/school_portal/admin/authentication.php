<?php
global $conn;
if(isset($_SESSION['loggedIn'])){
    $email = validate($_SESSION['loggedInUser']['email']);
    $query= "SELECT * FROM admins WHERE email='$email'";
    $result = mysqli_query($conn,$query);
    if(mysqli_num_rows($result)==0){
        logoutSession();
        redirect('../login.php','Access Denied');
    }
}
else{
    redirect('../login.php','Login To Continue');
}

