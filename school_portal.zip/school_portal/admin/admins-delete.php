
<?php
require(__DIR__.'/views/header.php');
$paraResult = checkParamId('pk');
if(is_numeric($paraResult)){
    echo $paraResult;
    $admin = getById('admins',$paraResult);
    if($admin['status']==200){
        $adminDelete = delete('admins',$paraResult);
        if($adminDelete){
            redirect('admins.php','Admin Deleted Successfully');
        }
        else{
            redirect('admins.php','Something Went Wrong');
        }
    }else{
        redirect('admins.php',$admin['message']);
    }
}else{
    redirect('admins.php','Something Went Wrong');
}
