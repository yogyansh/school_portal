<?php
require(__DIR__.'/views/header.php');
global $conn;
if(isset($_POST['save'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];

    $emailCheck = mysqli_query($conn, "SELECT * FROM admins WHERE email='$email'");
    if ($emailCheck) {
        if (mysqli_num_rows($emailCheck) > 0) {
            redirect('admins-create.php', 'Email Already used by another user!');
        }
    }

    $cript_password = password_hash($password, PASSWORD_BCRYPT);
    if ($name != '' && $email != '' && $password != '') {
        $data = [
            "name" => $name,
            "email" => $email,
            "phone_number" => $phone,
            "password" => $cript_password
        ];

        $getResult = insertData('admins', $data);
        if ($getResult) {
            redirect('admins.php', 'Record inserted successfully!');
        } else {
            redirect('admins-create.php', 'Something went wrong!');
        }
    } else {
        redirect('admins-create.php', 'Please fill required details!');
    }
}
if(isset($_POST['updateAdmin'])){
    $adminId = $_POST['adminId'];
    $adminData = getById('admins',$adminId);
    if($adminData['status']!=200){
        redirect('admins-edit.php?pk='.$adminId, 'Please fill required details!');
    }
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];

    if($password!= ''){
        $hashedPassword = password_hash($password,PASSWORD_BCRYPT);
    }else{
        $hashedPassword = $adminData['data']['password'];
    }

    if($name!='' && $email!=''){
        $data = [
            "name" => $name,
            "email" => $email,
            "phone_number" => $phone,
            "password" => $hashedPassword
        ];

        $getResult = update('admins',$adminId, $data);

        if ($getResult) {
            redirect('admins.php?pk='.$adminId, 'Record update successfully!');
        } else {
            redirect('admins-edit.php?pk='.$adminId, 'Something went wrong!');
        }
    }else{
        redirect('admins-edit.php?pk='.$adminId, 'Please fill required details!');
    }
}
if(isset($_POST['saveDepartment'])){
    $name = validate($_POST['name']);
    $description = validate($_POST['description']);
    $status = isset($_POST['status'])==true ? 0:1;

    $data = [
        "name" => $name,
        "description" => $description,
        "status" => $status
    ];

    $getResult = insertData('department', $data);
    if ($getResult) {
        redirect('department.php', 'Record inserted successfully!');
    } else {
        redirect('department-create.php', 'Something went wrong!');
    }
}


